import 'package:flutter/material.dart';

void main() {
  runApp(const MeuApp());
}

class MeuApp extends StatefulWidget {
  const MeuApp({super.key});

  @override
  State<MeuApp> createState() => _MeuAppState();
}

class _MeuAppState extends State<MeuApp> {
  bool darkMode = false; //voltar a ccor original
  int indceCor = 0; //sempre inicializa a variavel com zero

  Color corFundo = Colors.blue.shade100;
  void mudarCor() {
    setState(() {
      indceCor++;
      switch (indceCor) {
        case 1:
          corFundo = Colors.green.shade100;
          break;
        case 2:
          corFundo = Colors.amber.shade100;
          break;
        case 3:
          corFundo = Colors.cyan.shade100;
          break;
        default:
          indceCor = 0;
          corFundo = Colors.blue.shade100;
      }
    });
  }

  void alternarDark() {
    setState(() {
      darkMode = !darkMode; //! é negação ? é condição
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: corFundo,
        primaryColor: Colors.blue,
      ),

      darkTheme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
      ),
      themeMode: darkMode
          ? ThemeMode.dark
          : ThemeMode
                .light, // operação ternaria, se o themeMode for verdadeiro ela coloca dark se for false coloca light
      home: TelaIMC(mudarCor: mudarCor, alternatdark: alternarDark),
    );
  }
}

class TelaIMC extends StatefulWidget {
  final Function mudarCor;
  final Function alternatdark;

  const TelaIMC({
    super.key,
    required this.mudarCor,
    required this.alternatdark,
  });

  @override
  State<TelaIMC> createState() => _TelaIMCState();
}

class _TelaIMCState extends State<TelaIMC> {
  final nomeController = TextEditingController();
  final idadeController = TextEditingController();
  final alturaController = TextEditingController();
  final pesoController = TextEditingController();
  String resultado = "";
  double imc = 0;

  Color corResultado = Colors.black;
  IconData iconsaude = Icons.favorite;
  void calcularIMC() {
    if (nomeController
            .text
            .isEmpty || //o isEmpty serve para verificar se a variavel esta vazia
        idadeController.text.isEmpty || // || significa "ou"
        alturaController.text.isEmpty ||
        pesoController.text.isEmpty) {
      setState(() {
        resultado = "Preencha todos os campos";
      });
      return;
    }
    double altura = double.parse(alturaController.text.replaceAll(",", "."));
    double peso = double.parse(pesoController.text.replaceAll(",", "."));
    imc = peso / (altura * altura);

    String classificacao = "";

    if (imc < 18.5) {
      classificacao = "Abaixo do peso";
      corResultado = Colors.blue;
      iconsaude = Icons.sentiment_dissatisfied;
    } else if (imc < 25) {
      classificacao = "Peso normal";
      corResultado = Colors.green;
      iconsaude = Icons.sentiment_satisfied;
    } else if (imc < 30) {
      classificacao = "Sobrepeso";
      corResultado = Colors.orange;
      iconsaude = Icons.warning;
    } else if (imc < 35) {
      classificacao = "Obsidade grau 01";
      corResultado = Colors.red;
      iconsaude = Icons.health_and_safety;
    } else if (imc < 40) {
      classificacao = "Obsidade grau 02";
      corResultado = Colors.redAccent;
      iconsaude = Icons.error;
    } else {
      classificacao = "Obsidade grau 03";
      corResultado = Colors.purple;
      iconsaude = Icons.dangerous;
    }
    setState(() {
      resultado =
          "${nomeController.text}, ${idadeController.text} anos\n\n"
          "Seu IMC é: ${imc.toStringAsFixed(2).replaceAll(".", ",")} \n\n";
      "Classificação: $classificacao";
    });
  }

  void limpar() {
    setState(() {
      nomeController.clear();
      idadeController.clear();
      alturaController.clear();
      pesoController.clear();
      resultado = "";
      imc = 0;
      corResultado = Colors.black;
      iconsaude = Icons.favorite;
    });
  }

  // colar o c[odigo aqui
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,

      appBar: AppBar(
        title: const Text("Calculadora de IMC"),
        centerTitle: true,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),

          child: Column(
            children: [
              TextField(
                controller: nomeController,
                decoration: const InputDecoration(
                  labelText: "Nome",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: idadeController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Idade",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.cake),
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: alturaController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Altura (Ex: 1,75)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.height),
                ),
              ),

              const SizedBox(height: 10),

              TextField(
                controller: pesoController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: "Peso (Ex: 70,5)",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.monitor_weight),
                ),
              ),

              const SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: calcularIMC,
                    icon: const Icon(Icons.calculate),
                    label: const Text("Calcular"),
                  ),
                  ElevatedButton.icon(
                    onPressed: limpar,
                    icon: const Icon(Icons.cleaning_services),
                    label: const Text("Limpar"),
                  ),
                ],
              ),

              const SizedBox(height: 10),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    onPressed: () => widget.mudarCor(),
                    icon: const Icon(Icons.palette),
                    label: const Text("Cor"),
                  ),
                  ElevatedButton.icon(
                    onPressed: () => widget.alternatdark(),
                    icon: const Icon(Icons.dark_mode),
                    label: const Text("Dark"),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              if (resultado.isNotEmpty)
                Card(
                  elevation: 8,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),

                  child: Padding(
                    padding: const EdgeInsets.all(25),

                    child: Column(
                      children: [
                        Icon(iconsaude, size: 70, color: corResultado),

                        const SizedBox(height: 15),

                        Text(
                          resultado,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: corResultado,
                          ),
                        ),

                        const SizedBox(height: 20),

                        ClipRRect(
                          borderRadius: BorderRadius.circular(10),

                          child: LinearProgressIndicator(
                            value: imc == 0 ? 0 : (imc / 40).clamp(0.0, 1.0),
                            minHeight: 20,
                            backgroundColor: Colors.grey,
                            color: corResultado,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
